<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin','official');
$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); $action=$_POST['action']??'';
    if($action==='save'){
        $memberId=(int)($_POST['member_id']??0);$departmentId=($_POST['department_id']??'')!==''?(int)$_POST['department_id']:null;
        $amount=filter_var($_POST['amount']??'',FILTER_VALIDATE_FLOAT);$purpose=trim((string)($_POST['purpose']??''));$method=(string)($_POST['payment_method']??'cash');
        $reference=trim((string)($_POST['reference']??''));$status=(string)($_POST['payment_status']??'paid');$date=(string)($_POST['payment_date']??date('Y-m-d'));
        $validMember=$pdo->prepare("SELECT id FROM members WHERE id=? AND status='active'");$validMember->execute([$memberId]);
        if(!$validMember->fetch())$errors[]='Choose an active member.';
        if($amount===false||$amount<=0||$amount>100000000)$errors[]='Enter a valid positive amount.';
        if($purpose==='')$errors[]='Enter the contribution purpose.';
        if(!in_array($method,['cash','bank','other'],true))$errors[]='Invalid payment method.';
        if(!in_array($status,['paid','pending','cancelled'],true))$errors[]='Invalid payment status.';
        $dateObj=DateTime::createFromFormat('Y-m-d',$date);
        if(!$dateObj||$dateObj->format('Y-m-d')!==$date)$errors[]='Enter a valid payment date.';
        if(!$errors){
            $s=$pdo->prepare('INSERT INTO contributions (member_id, department_id, amount, purpose, payment_method, reference, payment_status, payment_date, recorded_by) VALUES (?,?,?,?,?,?,?,?,?)');
            $s->execute([$memberId,$departmentId,$amount,$purpose,$method,$reference?:null,$status,$date,$_SESSION['user_id']]);
            log_action($pdo,'record_contribution','Contribution ID '.$pdo->lastInsertId());flash('Contribution record saved.');header('Location: contributions.php');exit;
        }
    }elseif($action==='status'){
        $id=(int)($_POST['id']??0);$status=(string)($_POST['payment_status']??'pending');
        if(in_array($status,['paid','pending','cancelled'],true)){$s=$pdo->prepare('UPDATE contributions SET payment_status=? WHERE id=?');$s->execute([$status,$id]);log_action($pdo,'update_contribution_status','Contribution ID '.$id.' -> '.$status);flash('Contribution status updated.');}
        header('Location: contributions.php');exit;
    }
}
$members=$pdo->query("SELECT id,full_name FROM members WHERE status='active' ORDER BY full_name")->fetchAll();
$departments=$pdo->query('SELECT id,name FROM departments ORDER BY name')->fetchAll();
$rows=$pdo->query('SELECT c.*,m.full_name AS member_name,d.name AS department_name,u.full_name AS recorder FROM contributions c JOIN members m ON c.member_id=m.id LEFT JOIN departments d ON c.department_id=d.id LEFT JOIN users u ON c.recorded_by=u.id ORDER BY c.payment_date DESC,c.id DESC LIMIT 300')->fetchAll();
$pageTitle='Contributions';require __DIR__.'/includes/header.php';
?>
<section class="page-heading"><div><span class="eyebrow">WELFARE & COMMUNITY FUNDS</span><h1>Contributions</h1><p>Record manual payments only. This version does not process M-Pesa payments automatically.</p></div></section>
<?php foreach($errors as $error): ?><div class="alert error"><?=e($error)?></div><?php endforeach; ?>
<div class="two-column">
<section class="panel"><h2>Record contribution</h2>
<?php if(!$members): ?><div class="alert error">Add an active member before recording a contribution.</div><?php endif; ?>
<form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save">
<label>Member *<select name="member_id" required><option value="">Select member</option><?php foreach($members as $m): ?><option value="<?=(int)$m['id']?>"><?=e($m['full_name'])?></option><?php endforeach; ?></select></label>
<label>Department<select name="department_id"><option value="">General / not specified</option><?php foreach($departments as $d): ?><option value="<?=(int)$d['id']?>"><?=e($d['name'])?></option><?php endforeach; ?></select></label>
<label>Amount (KSh) *<input type="number" name="amount" min="0.01" step="0.01" required></label>
<label>Purpose *<input name="purpose" maxlength="255" required placeholder="e.g. Welfare contribution"></label>
<label>Payment method<select name="payment_method"><option value="cash">Cash</option><option value="bank">Bank</option><option value="other">Other</option></select></label>
<label>Reference / receipt number<input name="reference" maxlength="120"></label>
<label>Payment status<select name="payment_status"><option value="paid">Paid</option><option value="pending">Pending</option><option value="cancelled">Cancelled</option></select></label>
<label>Payment date<input type="date" name="payment_date" value="<?=e(date('Y-m-d'))?>" required></label>
<button class="button" type="submit" <?=!$members?'disabled':''?>>Save contribution</button></form></section>
<section class="panel"><div class="table-heading"><div><h2>Recent contributions</h2><p class="muted small">Latest 300 records.</p></div><a class="button button-small" href="reports.php">Reports</a></div><div class="table-wrap"><table><thead><tr><th>Date / Member</th><th>Purpose</th><th>Amount</th><th>Status</th><th>Update</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=e($r['payment_date'])?><small><?=e($r['member_name'])?></small></td><td><?=e($r['purpose'])?><small><?=e($r['department_name']??'General')?></small></td><td>KSh <?=number_format((float)$r['amount'],2)?></td><td><span class="badge <?=e($r['payment_status'])?>"><?=e(ucfirst($r['payment_status']))?></span></td><td><form method="post" class="status-form"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?=(int)$r['id']?>"><select name="payment_status"><option value="paid" <?=$r['payment_status']==='paid'?'selected':''?>>Paid</option><option value="pending" <?=$r['payment_status']==='pending'?'selected':''?>>Pending</option><option value="cancelled" <?=$r['payment_status']==='cancelled'?'selected':''?>>Cancelled</option></select><button class="text-button">Save</button></form></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="5" class="empty">No contribution records yet.</td></tr><?php endif; ?></tbody></table></div></section></div>
<?php require __DIR__.'/includes/footer.php'; ?>
