<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}
$pageTitle = 'SIKULU B Village Management System';
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
    <div class="hero-copy">
        <span class="eyebrow">COMMUNITY · SERVICE · ACCOUNTABILITY</span>
        <h1>Working together for a stronger <span>SIKULU B.</span></h1>
        <p>A central place for authorized village officials to manage member records, staff, departments, welfare activities, and contribution records.</p>
        <div class="hero-actions"><a class="button" href="login.php">Sign in to the system</a><a class="button button-light" href="#features">Explore features</a></div>
        <p class="small muted">Access is restricted to accounts created by an authorized administrator.</p>
    </div>
    <div class="hero-card">
        <div class="village-icon">⌂</div>
        <h2>SIKULU B</h2>
        <p>Kituni Sub-location<br>Misikhu Ward · Webuye West<br>Bungoma County, Kenya</p>
        <div class="hero-divider"></div><div class="hero-stat"><span>One community</span><strong>Shared progress</strong></div>
    </div>
</section>
<section id="features" class="section">
    <div class="section-heading"><span class="eyebrow">SYSTEM FEATURES</span><h2>Village information, organized</h2><p>Designed for authorized officials and members, with role-based access.</p></div>
    <div class="feature-grid">
        <article class="feature"><span class="feature-icon">♙</span><h3>Member records</h3><p>Maintain member contacts, household references, and status.</p></article>
        <article class="feature"><span class="feature-icon">▦</span><h3>Staff and departments</h3><p>Record village staff and organize village departments.</p></article>
        <article class="feature"><span class="feature-icon">KSh</span><h3>Contributions</h3><p>Record manual contribution payments and payment references.</p></article>
        <article class="feature"><span class="feature-icon">▤</span><h3>Reports</h3><p>View summaries and export authorized records as CSV.</p></article>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
