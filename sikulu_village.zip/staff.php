<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin', 'official');
$errors = []; $editing = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id=(int)($_POST['id']??0); $name=trim((string)($_POST['full_name']??'')); $position=trim((string)($_POST['position']??''));
        $phone=trim((string)($_POST['phone']??'')); $department=trim((string)($_POST['department']??'')); $status=(string)($_POST['status']??'active');
        if ($name==='' || $position==='') $errors[]='Name and position are required.';
        if (!in_array($status,['active','inactive'],true)) $errors[]='Invalid status.';
        if (!$errors) {
            if ($id) {
                $s=$pdo->prepare('UPDATE staff SET full_name=?, position=?, phone=?, department=?, status=? WHERE id=?');
                $s->execute([$name,$position,$phone?:null,$department?:null,$status,$id]); flash('Staff record updated.');
            } else {
                $s=$pdo->prepare('INSERT INTO staff (full_name, position, phone, department, status) VALUES (?,?,?,?,?)');
                $s->execute([$name,$position,$phone?:null,$department?:null,$status]); flash('Staff record added.');
            }
            log_action($pdo,$id?'update_staff':'create_staff','Staff ID '.($id?:$pdo->lastInsertId()));
            header('Location: staff.php'); exit;
        }
        $editing=['id'=>$id,'full_name'=>$name,'position'=>$position,'phone'=>$phone,'department'=>$department,'status'=>$status];
    } elseif ($action==='delete') {
        $s=$pdo->prepare("UPDATE staff SET status='inactive' WHERE id=?"); $s->execute([(int)$_POST['id']]); flash('Staff marked inactive.'); header('Location: staff.php'); exit;
    }
}
if (!$editing && isset($_GET['edit'])) { $s=$pdo->prepare('SELECT * FROM staff WHERE id=?'); $s->execute([(int)$_GET['edit']]); $editing=$s->fetch()?:null; }
$staff=$pdo->query('SELECT * FROM staff ORDER BY created_at DESC LIMIT 300')->fetchAll();
$pageTitle='Village staff'; require __DIR__.'/includes/header.php';
?>
<section class="page-heading"><div><span class="eyebrow">PEOPLE & RESPONSIBILITIES</span><h1>Village staff</h1><p>Manage staff names, positions, contacts and departments.</p></div></section>
<div class="two-column">
<section class="panel"><h2><?= $editing?'Edit staff':'Add staff member' ?></h2><?php foreach($errors as $error): ?><div class="alert error"><?=e($error)?></div><?php endforeach; ?>
<form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)($editing['id']??0)?>">
<label>Full name *<input name="full_name" required maxlength="120" value="<?=e($editing['full_name']??'')?>"></label>
<label>Position *<input name="position" required maxlength="120" placeholder="e.g. Welfare coordinator" value="<?=e($editing['position']??'')?>"></label>
<label>Phone<input name="phone" maxlength="30" value="<?=e($editing['phone']??'')?>"></label>
<label>Department<input name="department" maxlength="120" value="<?=e($editing['department']??'')?>"></label>
<label>Status<select name="status"><option value="active" <?=($editing['status']??'active')==='active'?'selected':''?>>Active</option><option value="inactive" <?=($editing['status']??'')==='inactive'?'selected':''?>>Inactive</option></select></label>
<div class="form-actions"><button class="button"><?= $editing?'Save changes':'Add staff' ?></button><?php if($editing): ?><a class="button button-light" href="staff.php">Cancel</a><?php endif; ?></div></form></section>
<section class="panel"><h2>Staff directory</h2><div class="table-wrap"><table><thead><tr><th>Name</th><th>Position / Department</th><th>Phone</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($staff as $s): ?><tr><td><?=e($s['full_name'])?></td><td><?=e($s['position'])?><small><?=e($s['department']??'')?></small></td><td><?=e($s['phone']??'—')?></td><td><span class="badge <?=e($s['status'])?>"><?=e(ucfirst($s['status']))?></span></td><td class="actions"><a href="staff.php?edit=<?=(int)$s['id']?>">Edit</a><form method="post" onsubmit="return confirm('Mark this staff record inactive?')"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$s['id']?>"><button class="text-button">Deactivate</button></form></td></tr><?php endforeach; ?>
<?php if(!$staff): ?><tr><td colspan="5" class="empty">No staff records yet.</td></tr><?php endif; ?></tbody></table></div></section></div>
<?php require __DIR__.'/includes/footer.php'; ?>
