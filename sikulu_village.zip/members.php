<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin', 'official');
$errors = [];
$editing = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['full_name'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $household = trim((string)($_POST['household_reference'] ?? ''));
        $address = trim((string)($_POST['address'] ?? ''));
        $status = (string)($_POST['status'] ?? 'active');
        if ($name === '' || mb_strlen($name) > 120) $errors[] = 'Enter a member name (maximum 120 characters).';
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address or leave it blank.';
        if (!in_array($status, ['active','inactive'], true)) $errors[] = 'Invalid status.';
        if (!$errors) {
            if ($id > 0) {
                $stmt = $pdo->prepare('UPDATE members SET full_name=?, phone=?, email=?, household_reference=?, address=?, status=? WHERE id=?');
                $stmt->execute([$name, $phone ?: null, $email ?: null, $household ?: null, $address ?: null, $status, $id]);
                log_action($pdo, 'update_member', 'Member ID ' . $id);
                flash('Member updated successfully.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO members (full_name, phone, email, household_reference, address, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$name, $phone ?: null, $email ?: null, $household ?: null, $address ?: null, $status, $_SESSION['user_id']]);
                log_action($pdo, 'create_member', 'Member ID ' . $pdo->lastInsertId());
                flash('Member added successfully.');
            }
            header('Location: members.php'); exit;
        }
        $editing = ['id'=>$id,'full_name'=>$name,'phone'=>$phone,'email'=>$email,'household_reference'=>$household,'address'=>$address,'status'=>$status];
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE members SET status='inactive' WHERE id=?");
        $stmt->execute([$id]);
        log_action($pdo, 'deactivate_member', 'Member ID ' . $id);
        flash('Member marked inactive.');
        header('Location: members.php'); exit;
    }
}
if (!$editing && isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM members WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}
$q = trim((string)($_GET['q'] ?? ''));
if ($q !== '') {
    $like = '%' . $q . '%';
    $stmt = $pdo->prepare('SELECT * FROM members WHERE full_name LIKE ? OR phone LIKE ? OR household_reference LIKE ? ORDER BY created_at DESC LIMIT 200');
    $stmt->execute([$like, $like, $like]); $members = $stmt->fetchAll();
} else {
    $members = $pdo->query('SELECT * FROM members ORDER BY created_at DESC LIMIT 200')->fetchAll();
}
$pageTitle = 'Members';
require __DIR__ . '/includes/header.php';
?>
<section class="page-heading"><div><span class="eyebrow">COMMUNITY DIRECTORY</span><h1>Members</h1><p>Store and maintain member records. Only collect information needed for village administration.</p></div></section>
<div class="two-column">
<section class="panel"><h2><?= $editing ? 'Edit member' : 'Add member' ?></h2>
<?php foreach ($errors as $error): ?><div class="alert error"><?= e($error) ?></div><?php endforeach; ?>
<form method="post" class="form-stack">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($editing['id'] ?? 0) ?>">
<label>Full name *<input name="full_name" required maxlength="120" value="<?= e($editing['full_name'] ?? '') ?>"></label>
<label>Phone number<input name="phone" maxlength="30" value="<?= e($editing['phone'] ?? '') ?>"></label>
<label>Email address<input type="email" name="email" maxlength="190" value="<?= e($editing['email'] ?? '') ?>"></label>
<label>Household reference<input name="household_reference" maxlength="80" value="<?= e($editing['household_reference'] ?? '') ?>"></label>
<label>Address / location<input name="address" maxlength="255" value="<?= e($editing['address'] ?? '') ?>"></label>
<label>Status<select name="status"><option value="active" <?= ($editing['status'] ?? 'active')==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= ($editing['status'] ?? '')==='inactive'?'selected':'' ?>>Inactive</option></select></label>
<div class="form-actions"><button class="button" type="submit"><?= $editing ? 'Save changes' : 'Add member' ?></button><?php if ($editing): ?><a class="button button-light" href="members.php">Cancel</a><?php endif; ?></div>
</form></section>
<section class="panel"><div class="table-heading"><div><h2>Member directory</h2><p class="muted small">Showing up to 200 records.</p></div><form method="get" class="search-form"><input name="q" placeholder="Search name, phone, household" value="<?= e($q) ?>"><button class="button button-small">Search</button></form></div>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Contact</th><th>Household</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($members as $m): ?><tr><td><strong><?= e($m['full_name']) ?></strong><small><?= e($m['address'] ?? '') ?></small></td><td><?= e($m['phone'] ?? '—') ?><small><?= e($m['email'] ?? '') ?></small></td><td><?= e($m['household_reference'] ?? '—') ?></td><td><span class="badge <?= e($m['status']) ?>"><?= e(ucfirst($m['status'])) ?></span></td><td class="actions"><a href="members.php?edit=<?= (int)$m['id'] ?>">Edit</a><form method="post" onsubmit="return confirm('Mark this member inactive?')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><button class="text-button" type="submit">Deactivate</button></form></td></tr><?php endforeach; ?>
<?php if (!$members): ?><tr><td colspan="5" class="empty">No members found.</td></tr><?php endif; ?>
</tbody></table></div></section></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
