<?php
/*
 * ONE-TIME LOCAL SETUP ONLY.
 * Run locally after importing database.sql, create an admin, then DELETE this file.
 * Do not upload this file to public hosting.
 */
require_once __DIR__ . '/includes/bootstrap.php';
$count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $count === 0) {
    verify_csrf();
    $name=trim((string)($_POST['full_name']??''));$email=trim((string)($_POST['email']??''));$pass=(string)($_POST['password']??'');$confirm=(string)($_POST['confirm_password']??'');
    if($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) $message='Enter a name and valid email.';
    elseif(strlen($pass)<12) $message='Use a password with at least 12 characters.';
    elseif($pass!==$confirm) $message='Passwords do not match.';
    else {
        try {
            $s=$pdo->prepare("INSERT INTO users (full_name,email,password_hash,role,status) VALUES (?,?,?,'admin','active')");
            $s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);
            $message='Administrator created. DELETE setup_admin.php now, then sign in at login.php.';
            $count=1;
        } catch(PDOException $e) { $message='Could not create administrator. The email may already exist.'; }
    }
}
$pageTitle='Create first administrator';require __DIR__.'/includes/header.php';
?>
<div class="auth-layout"><section class="auth-aside"><span class="eyebrow">ONE-TIME SETUP</span><h1>Create your first administrator.</h1><p>This page is for local setup only. Never leave it accessible on a public website.</p></section><section class="panel auth-panel"><h2>Administrator account</h2>
<?php if($message): ?><div class="alert <?= $count?'success':'error' ?>"><?=e($message)?></div><?php endif; ?>
<?php if($count===0): ?><form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><label>Full name<input name="full_name" required maxlength="120"></label><label>Email<input type="email" name="email" required maxlength="190"></label><label>Password (12+ characters)<input type="password" name="password" required minlength="12" autocomplete="new-password"></label><label>Confirm password<input type="password" name="confirm_password" required minlength="12" autocomplete="new-password"></label><button class="button">Create administrator</button></form><?php else: ?><p>Setup is closed because an administrator exists. Delete this file and sign in.</p><?php endif; ?></section></div>
<?php require __DIR__.'/includes/footer.php'; ?>
