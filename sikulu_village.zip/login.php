<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $passwordInput = (string)($_POST['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $passwordInput === '') {
        $errors[] = 'Enter a valid email address and password.';
    } else {
        $stmt = $pdo->prepare('SELECT id, full_name, email, password_hash, role, status FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && $user['status'] === 'active' && password_verify($passwordInput, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            log_action($pdo, 'login', 'Successful login');
            header('Location: dashboard.php');
            exit;
        }
        $errors[] = 'Sign-in failed. Check your details or contact the system administrator.';
    }
}
$pageTitle = 'Sign in';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-layout">
    <section class="auth-aside"><span class="eyebrow">WELCOME BACK</span><h1>Manage village services with clarity.</h1><p>Sign in using the account provided by your administrator.</p><ul><li>Role-based access</li><li>Member and staff records</li><li>Manual contribution tracking</li></ul></section>
    <section class="panel auth-panel"><h2>Sign in</h2><p class="muted">Enter your registered account details.</p>
        <?php foreach ($errors as $error): ?><div class="alert error"><?= e($error) ?></div><?php endforeach; ?>
        <form method="post" class="form-stack">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <label>Email address<input type="email" name="email" required autocomplete="username" value="<?= e($_POST['email'] ?? '') ?>"></label>
            <label>Password<input type="password" name="password" required autocomplete="current-password"></label>
            <button class="button full-width" type="submit">Sign in securely</button>
        </form>
        <p class="small muted">Accounts are created by an authorized administrator. There is no public registration form.</p>
    </section>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
