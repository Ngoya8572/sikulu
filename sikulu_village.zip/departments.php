<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin','official');
$errors=[]; $editing=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); $action=$_POST['action']??'';
    if($action==='save'){
        $id=(int)($_POST['id']??0); $name=trim((string)($_POST['name']??'')); $description=trim((string)($_POST['description']??''));
        if($name==='') $errors[]='Department name is required.';
        if(!$errors){
            try{
                if($id){$s=$pdo->prepare('UPDATE departments SET name=?, description=? WHERE id=?');$s->execute([$name,$description?:null,$id]);flash('Department updated.');}
                else{$s=$pdo->prepare('INSERT INTO departments (name, description, created_by) VALUES (?,?,?)');$s->execute([$name,$description?:null,$_SESSION['user_id']]);flash('Department created.');}
                log_action($pdo,$id?'update_department':'create_department',$name);header('Location: departments.php');exit;
            }catch(PDOException $e){$errors[]='That department name may already exist.';}
        }
        $editing=['id'=>$id,'name'=>$name,'description'=>$description];
    }elseif($action==='delete'){
        $s=$pdo->prepare('DELETE FROM departments WHERE id=?');$s->execute([(int)$_POST['id']]);log_action($pdo,'delete_department','Department ID '.(int)$_POST['id']);flash('Department deleted.');header('Location: departments.php');exit;
    }
}
if(!$editing&&isset($_GET['edit'])){$s=$pdo->prepare('SELECT * FROM departments WHERE id=?');$s->execute([(int)$_GET['edit']]);$editing=$s->fetch()?:null;}
$departments=$pdo->query('SELECT d.*, u.full_name AS creator FROM departments d LEFT JOIN users u ON d.created_by=u.id ORDER BY d.name')->fetchAll();
$pageTitle='Departments';require __DIR__.'/includes/header.php';
?>
<section class="page-heading"><div><span class="eyebrow">VILLAGE ORGANIZATION</span><h1>Departments</h1><p>Create departments such as Welfare, Development, Security, Youth, and Other Contributions.</p></div></section>
<div class="two-column">
<section class="panel"><h2><?= $editing?'Edit department':'Add department' ?></h2><?php foreach($errors as $error): ?><div class="alert error"><?=e($error)?></div><?php endforeach; ?>
<form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)($editing['id']??0)?>">
<label>Department name *<input name="name" required maxlength="120" value="<?=e($editing['name']??'')?>"></label><label>Description<textarea name="description" rows="4" maxlength="1000"><?=e($editing['description']??'')?></textarea></label>
<div class="form-actions"><button class="button"><?= $editing?'Save changes':'Create department' ?></button><?php if($editing): ?><a class="button button-light" href="departments.php">Cancel</a><?php endif; ?></div></form></section>
<section class="panel"><h2>Current departments</h2><div class="table-wrap"><table><thead><tr><th>Department</th><th>Description</th><th>Action</th></tr></thead><tbody>
<?php foreach($departments as $d): ?><tr><td><strong><?=e($d['name'])?></strong></td><td><?=e($d['description']??'—')?></td><td class="actions"><a href="departments.php?edit=<?=(int)$d['id']?>">Edit</a><form method="post" onsubmit="return confirm('Delete this department?')"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$d['id']?>"><button class="text-button">Delete</button></form></td></tr><?php endforeach; ?>
<?php if(!$departments): ?><tr><td colspan="3" class="empty">No departments yet.</td></tr><?php endif; ?></tbody></table></div></section></div>
<?php require __DIR__.'/includes/footer.php'; ?>
