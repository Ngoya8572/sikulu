document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('form[onsubmit]').forEach(function (form) {
        // Inline confirmation handlers in the markup are intentionally preserved.
    });
});
