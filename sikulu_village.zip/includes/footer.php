</main>
<footer class="footer">
    <p>SIKULU B Village Management System · Kituni Sub-location, Misikhu Ward, Webuye West, Bungoma County, Kenya</p>
    <p class="muted">Use authorized accounts only. Keep resident and payment information confidential.</p>
</footer>
<script src="js/script.js"></script>
</body>
</html>
