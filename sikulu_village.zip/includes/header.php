<?php
$pageTitle = $pageTitle ?? 'SIKULU B Village Management System';
$flashMessage = take_flash();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="topbar">
    <a class="brand" href="<?= is_logged_in() ? 'dashboard.php' : 'index.php' ?>">
        <span class="brand-mark">SB</span>
        <span><strong>SIKULU B</strong><small>Village Management System</small></span>
    </a>
    <button class="menu-toggle" type="button" aria-label="Toggle menu" onclick="document.body.classList.toggle('nav-open')">☰</button>
    <nav class="nav">
        <?php if (is_logged_in()): ?>
            <a href="dashboard.php">Dashboard</a>
            <?php if (($_SESSION['role'] ?? '') === 'admin' || ($_SESSION['role'] ?? '') === 'official'): ?>
                <a href="members.php">Members</a>
                <a href="staff.php">Staff</a>
                <a href="departments.php">Departments</a>
                <a href="contributions.php">Contributions</a>
                <a href="reports.php">Reports</a>
            <?php endif; ?>
            <span class="user-chip"><?= e($_SESSION['full_name'] ?? '') ?> · <?= e(ucfirst($_SESSION['role'] ?? 'member')) ?></span>
            <form class="inline-form" action="logout.php" method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <button class="nav-logout" type="submit">Sign out</button>
            </form>
        <?php else: ?>
            <a href="index.php">Home</a><a class="nav-login" href="login.php">Sign in</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">
<?php if ($flashMessage): ?>
    <div class="alert <?= e($flashMessage['type']) ?>"><?= e($flashMessage['message']) ?></div>
<?php endif; ?>
