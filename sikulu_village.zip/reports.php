<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin','official');
$membersCount=(int)$pdo->query('SELECT COUNT(*) FROM members')->fetchColumn();
$activeMembers=(int)$pdo->query("SELECT COUNT(*) FROM members WHERE status='active'")->fetchColumn();
$staffCount=(int)$pdo->query("SELECT COUNT(*) FROM staff WHERE status='active'")->fetchColumn();
$paidTotal=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM contributions WHERE payment_status='paid'")->fetchColumn();
$pendingTotal=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM contributions WHERE payment_status='pending'")->fetchColumn();
$counts=$pdo->query('SELECT payment_status, COUNT(*) AS n FROM contributions GROUP BY payment_status')->fetchAll();
if(isset($_GET['export']) && $_GET['export']==='contributions'){
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="sikulu_contributions_'.date('Y-m-d').'.csv"');
    $out=fopen('php://output','w');
    fputcsv($out,['Date','Member','Department','Purpose','Amount KSh','Payment Method','Reference','Status']);
    $stmt=$pdo->query('SELECT c.payment_date,m.full_name,d.name,c.purpose,c.amount,c.payment_method,c.reference,c.payment_status FROM contributions c JOIN members m ON c.member_id=m.id LEFT JOIN departments d ON c.department_id=d.id ORDER BY c.payment_date DESC');
    while($row=$stmt->fetch(PDO::FETCH_NUM)) fputcsv($out,$row);
    fclose($out); log_action($pdo,'export_contributions','CSV export'); exit;
}
if(isset($_GET['export']) && $_GET['export']==='members'){
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="sikulu_members_'.date('Y-m-d').'.csv"');
    $out=fopen('php://output','w');fputcsv($out,['Name','Phone','Email','Household reference','Address','Status']);
    $stmt=$pdo->query('SELECT full_name,phone,email,household_reference,address,status FROM members ORDER BY full_name');
    while($row=$stmt->fetch(PDO::FETCH_NUM))fputcsv($out,$row);
    fclose($out);log_action($pdo,'export_members','CSV export');exit;
}
$pageTitle='Reports';require __DIR__.'/includes/header.php';
?>
<section class="page-heading"><div><span class="eyebrow">RECORDS & ACCOUNTABILITY</span><h1>Reports</h1><p>Summary of the records stored in this system. Verify figures against official receipts and accounts.</p></div></section>
<div class="stats-grid"><article class="stat-card"><span>All members</span><strong><?=number_format($membersCount)?></strong><small><?=$activeMembers?> active</small></article><article class="stat-card"><span>Active staff</span><strong><?=number_format($staffCount)?></strong><small>Staff records</small></article><article class="stat-card"><span>Confirmed paid</span><strong>KSh <?=number_format($paidTotal,2)?></strong><small>Marked as paid</small></article><article class="stat-card"><span>Pending</span><strong>KSh <?=number_format($pendingTotal,2)?></strong><small>Not counted as received</small></article></div>
<section class="panel section"><h2>Export records</h2><p class="muted">CSV files can be opened with Excel or LibreOffice. Exports may contain personal information; download and share them only when authorized.</p><div class="export-actions"><a class="button" href="reports.php?export=members">Export members CSV</a><a class="button button-light" href="reports.php?export=contributions">Export contributions CSV</a></div></section>
<section class="panel section"><h2>Contribution record counts</h2><div class="table-wrap"><table><thead><tr><th>Status</th><th>Number of records</th></tr></thead><tbody><?php foreach($counts as $c): ?><tr><td><span class="badge <?=e($c['payment_status'])?>"><?=e(ucfirst($c['payment_status']))?></span></td><td><?=number_format((int)$c['n'])?></td></tr><?php endforeach; ?><?php if(!$counts): ?><tr><td colspan="2" class="empty">No contributions recorded.</td></tr><?php endif; ?></tbody></table></div></section>
<?php require __DIR__.'/includes/footer.php'; ?>
