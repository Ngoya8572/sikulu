SIKULU B VILLAGE MANAGEMENT SYSTEM — PHP + MySQL

FEATURES
- Public landing page
- Sign-in with password hashing and role-based access (admin, official, member)
- Member directory: create, search, edit, deactivate
- Staff records: create, edit, deactivate
- Departments: create, edit, delete
- Manual contribution recording and status updates
- Dashboard summaries and CSV exports
- CSRF tokens, prepared SQL statements, output escaping, session regeneration, basic audit logs

IMPORTANT LIMITATIONS
- This is a starter implementation, not an audited production system.
- No automated M-Pesa payments, house/road map, password reset, member self-registration, or account management UI is included.
- Staff records are not user accounts. An administrator must be created locally using setup_admin.php; other accounts currently need to be added by a trusted administrator directly in the database (or by adding an account-management feature).
- Before production use, add backups, account administration, rate limiting, stronger operational monitoring, privacy notices, and independent security review.
- Never upload setup_admin.php to public hosting. Delete it after local administrator creation.
- Use fake test data until security and backups are verified.

LOCAL WINDOWS / XAMPP SETUP
1. Extract this ZIP to C:\xampp\htdocs\sikulu_village\
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/phpmyadmin/
4. Import database.sql. If phpMyAdmin refuses CREATE DATABASE permissions, create a database named sikulu_village first, select it, then import the SQL file (remove the first two CREATE DATABASE / USE lines if needed).
5. Check config/database.php uses 127.0.0.1, database sikulu_village, user root, blank password (typical default XAMPP setup).
6. Open http://localhost/sikulu_village/setup_admin.php and create an administrator using a strong password (12+ characters).
7. DELETE setup_admin.php immediately.
8. Open http://localhost/sikulu_village/login.php and sign in.
9. Add sample members and test all pages using fake data.

ONLINE HOSTING
1. Choose a PHP + MySQL host and create a free subdomain.
2. Create a MySQL database from the hosting control panel.
3. Export the local database using phpMyAdmin > Export > SQL; import it into the online database.
4. Upload project files to the web root (often htdocs or public_html). Do NOT upload setup_admin.php or README.txt.
5. Update config/database.php with the exact online DB host/name/user/password supplied by the provider. Never leave the local root credentials.
6. Create an admin account securely before making the system available. Do not publish setup_admin.php. For this starter project, the simplest safe route is to generate a password hash locally using PHP CLI and insert the admin row via the host's phpMyAdmin; SQL example is in ADMIN_ACCOUNT.txt.
7. Enable HTTPS, verify permissions and backups, test sign-in and access roles, and use fake data first.
8. Keep all credentials private. Do not commit config/database.php to public Git repositories.
