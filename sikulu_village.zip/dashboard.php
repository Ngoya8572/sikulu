<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$pageTitle = 'Dashboard';
$canManage = in_array($_SESSION['role'], ['admin', 'official'], true);
$stats = ['members' => 0, 'staff' => 0, 'departments' => 0, 'contributions' => 0, 'amount' => 0];
if ($canManage) {
    $stats['members'] = (int)$pdo->query("SELECT COUNT(*) FROM members WHERE status='active'")->fetchColumn();
    $stats['staff'] = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE status='active'")->fetchColumn();
    $stats['departments'] = (int)$pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
    $stats['contributions'] = (int)$pdo->query("SELECT COUNT(*) FROM contributions")->fetchColumn();
    $stats['amount'] = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM contributions WHERE payment_status='paid'")->fetchColumn();
}
require __DIR__ . '/includes/header.php';
?>
<section class="page-heading"><div><span class="eyebrow">OVERVIEW</span><h1>Good day, <?= e(explode(' ', trim($_SESSION['full_name']))[0]) ?>.</h1><p>Welcome to the SIKULU B village administration workspace.</p></div><span class="status-pill">● Account active</span></section>
<?php if ($canManage): ?>
<div class="stats-grid">
    <article class="stat-card"><span>Active members</span><strong><?= number_format($stats['members']) ?></strong><small>Registered member records</small></article>
    <article class="stat-card"><span>Active staff</span><strong><?= number_format($stats['staff']) ?></strong><small>Village staff records</small></article>
    <article class="stat-card"><span>Departments</span><strong><?= number_format($stats['departments']) ?></strong><small>Village departments</small></article>
    <article class="stat-card"><span>Paid contributions</span><strong>KSh <?= number_format($stats['amount'], 2) ?></strong><small><?= number_format($stats['contributions']) ?> total contribution records</small></article>
</div>
<section class="section"><div class="section-heading"><h2>Quick actions</h2><p>Choose an area to manage.</p></div><div class="quick-grid">
<a class="quick-card" href="members.php"><span>♙</span><strong>Manage members</strong><small>Add, search, edit and deactivate member records</small></a>
<a class="quick-card" href="staff.php"><span>▦</span><strong>Manage staff</strong><small>Maintain staff and roles in the village</small></a>
<a class="quick-card" href="departments.php"><span>▤</span><strong>Departments</strong><small>Manage welfare and other departments</small></a>
<a class="quick-card" href="contributions.php"><span>KSh</span><strong>Contributions</strong><small>Record and review manual payments</small></a>
<a class="quick-card" href="reports.php"><span>↗</span><strong>Reports</strong><small>Review totals and export CSV records</small></a>
</div></section>
<?php else: ?>
<section class="panel member-welcome"><span class="feature-icon">♙</span><h2>Member portal</h2><p>Your account has member access. Contact an authorized village official if your details need updating or if you need assistance with a contribution record.</p><p><strong>Account email:</strong> <?= e($_SESSION['email']) ?></p></section>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
